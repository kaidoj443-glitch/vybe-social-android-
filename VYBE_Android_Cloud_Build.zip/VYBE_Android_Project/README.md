# VYBE Social Android project

This is an Android Studio project for an installable Android shell around the deployed VYBE Social online app.

**Online app:** https://vybe-social-a7y2x2.v2.appdeploy.ai/

## Build an APK
1. Install Android Studio (current stable) on a computer.
2. Open this folder as an existing Gradle project.
3. Allow Gradle to sync and install Android SDK Platform 35 if prompted.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally under `app/build/outputs/apk/debug/`.
6. For distribution, configure a signing key and build a signed release APK.

## What this Android wrapper provides
- A launcher app named VYBE Social
- Full-screen embedded online VYBE website
- JavaScript and browser storage support for the existing sign-in/feed UI
- System back navigation
- External links open outside the app
- WebView file picker support if the hosted site adds file-upload inputs
- No cleartext HTTP content

## Important notes
- This package is Android source code, **not a prebuilt APK**.
- It requires an internet connection; the feed and accounts remain on the hosted service.
- The existing website's image composer currently uses a public HTTPS image URL field, not direct photo upload. Native photo upload needs matching upload support on the backend.
- No artificial files have been added to inflate the app size. APK size depends on build settings, Android architecture, SDK and bundled native assets. The requested 35 MB threshold is not a measure of quality; a minimal WebView app is usually much smaller.
- Before public release, test sign-in provider redirects, account persistence, privacy policy, account deletion, and store policies on real devices.

## Build an APK without a computer (GitHub Actions)

This repository includes `.github/workflows/build-apk.yml` to build a debug APK in GitHub's cloud.
You must upload the *contents* of this project folder to a GitHub repository (not just this ZIP file),
keeping the `.github/workflows/build-apk.yml` path intact. On GitHub, open the repository's Actions
tab, choose **Build VYBE Social APK**, then **Run workflow**. When the run finishes, open it and
download the `VYBE-Social-debug-APK` artifact. Extract the downloaded artifact on your Android phone
to get the `.apk`, then tap it to install. Android may ask you to allow installs from that browser or
file manager; only enable this for the app you intentionally downloaded.

This is a debug APK for personal testing, not a signed Play Store release. The app is a WebView wrapper
around the hosted VYBE Social website and needs internet access.
